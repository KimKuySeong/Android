package com.example.wjddu.myfirstapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class team_info extends AppCompatActivity {

    Button homebtn, clobtn;
    ImageView img1, img2, img3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_info);

        homebtn = findViewById(R.id.homebtn);
        clobtn = findViewById(R.id.clobtn);
        img1 = findViewById(R.id.img1);
        img2 = findViewById(R.id.img2);
        img3 = findViewById(R.id.img3);





        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(team_info.this);
                dialog.setTitle("김규성 소개")
                        .setMessage("취미 : 운동 \n좋아하는 색상 : 보라색 \n좋아하는 이모티콘 : ;D")
                        .setNegativeButton("종료", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(team_info.this, "소개 끝 *^__^*", Toast.LENGTH_SHORT).show();
                            }
                        }).create().show();
            }
        });


        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(team_info.this);
                dialog.setTitle("문정연 소개")
                        .setMessage("취미 : 음악 듣기 \n좋아하는 색상 : 하늘색 \n좋아하는 이모티콘 : ㅍㅅㅍ)!!")
                        .setNegativeButton("종료", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(team_info.this, "소개 끝 *^__^*", Toast.LENGTH_SHORT).show();
                            }
                        }).create().show();
            }
        });


        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder(team_info.this);
                dialog.setTitle("임혜빈 소개")
                        .setMessage("취미 : 게임 \n좋아하는 색상 : 파란색 \n좋아하는 이모티콘 : ㅇ0ㅇ")
                        .setNegativeButton("종료", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Toast.makeText(team_info.this, "소개 끝 *^__^*", Toast.LENGTH_SHORT).show();
                            }
                        }).create().show();
            }
        });


        homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent hintent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(hintent);
                Toast.makeText(getApplicationContext(), "홈 화면입니다", Toast.LENGTH_SHORT).show();
            }
        });


        clobtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                moveTaskToBack(true);
                Toast.makeText(getApplicationContext(), "어플을 종료했습니다.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
